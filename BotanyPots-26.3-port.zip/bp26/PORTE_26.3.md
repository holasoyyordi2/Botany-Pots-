# Botany Pots – intento de port no oficial a Minecraft 26.3 (Fabric)

Base: port no oficial a 26.1.x de mike-goldfinger, que a su vez parte del código de Darkhax (LGPL v2.1).
ESTADO: SIN COMPILAR NI PROBAR. Es un punto de partida, no un mod terminado.

## Ya cambiado
- Bookshelf 26.3.0.4, Prickle 26.3.0.2 y Fabric API 0.165.0+26.3 (existen para 26.3 en Fabric).
- Gradle 9.6.0 y workflow de GitHub Actions (.github/workflows/compilar.yml) que compila solo Fabric con JDK 25.

## Valores supuestos (pueden fallar en el primer build)
1. Plugin `net.darkhax.mmc` version "26.3.0.1" en build.gradle.kts: es una suposición. Si no existe,
   usa la versión real que publique Darkhax para 26.3.
2. JEI (dependencia opcional) sigue apuntando a 26.1.2; probablemente haya que actualizarla o quitar
   el código en common/.../addons/jei si no existe para 26.3.

## Zonas de riesgo conocidas en 26.3 (según las notas de Fabric)
26.3 cambió los registros recargables: ahora incluyen recetas y logros. Botany Pots guarda cultivos,
tierras y fertilizantes como recetas, así que lo más probable es que fallen o requieran reescritura:
- common/.../mixin/MixinRecipeManager.java (inyecta en RecipeManager.apply(RecipeMap,...))
- common/.../api/data/recipes/RecipeCache.java y api/function/ReloadableCache.java
- common/.../impl/data/SyncedRecipes.java y impl/BotanyPotsContent.java (registro de tipos de receta)
- fabric/.../BotanyPotsFabric.java
Cada error de compilación indica el archivo y la línea exactos.

## Cómo compilar sin instalar nada
1. Sube TODO el contenido de esta carpeta (incluida la oculta .github) a un repositorio de GitHub.
2. Pestaña Actions -> "Compilar Botany Pots (Fabric 26.3)" -> Run workflow.
3. Si falla, copia el error. Si termina, descarga el .jar en Artifacts.
4. Instálalo con Fabric API, Bookshelf 26.3.0.4 y Prickle 26.3.0.2.
