package net.darkhax.botanypots.common.impl.data.recipe.crop;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.darkhax.bookshelf.common.api.data.codecs.map.MapCodecs;
import net.darkhax.bookshelf.common.api.data.codecs.stream.StreamCodecs;
import net.darkhax.bookshelf.common.api.util.DataHelper;
import net.darkhax.botanypots.common.api.context.BlockEntityContext;
import net.darkhax.botanypots.common.api.context.BotanyPotContext;
import net.darkhax.botanypots.common.api.data.display.types.Display;
import net.darkhax.botanypots.common.api.data.display.types.DisplayType;
import net.darkhax.botanypots.common.api.data.itemdrops.ItemDropProvider;
import net.darkhax.botanypots.common.api.data.itemdrops.ItemDropProviderType;
import net.darkhax.botanypots.common.api.data.recipes.CacheableRecipe;
import net.darkhax.botanypots.common.api.data.recipes.crop.Crop;
import net.darkhax.botanypots.common.impl.BotanyPotsMod;
import net.darkhax.botanypots.common.impl.Helpers;
import net.darkhax.botanypots.common.impl.block.BotanyPotBlock;
import net.darkhax.botanypots.common.impl.block.entity.BotanyPotBlockEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.criterion.BlockPredicate;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.item.Item;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.StringUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class BasicCrop extends Crop implements CacheableRecipe {

    public static final TagKey<Item> DIRT_TAG = TagKey.create(Registries.ITEM, BotanyPotsMod.id("soil/dirt"));
    public static final MapCodec<BasicCrop> CODEC = Properties.CODEC.xmap(BasicCrop::new, BasicCrop::getBasicProperties);
    public static final StreamCodec<RegistryFriendlyByteBuf, BasicCrop> STREAM = Properties.STREAM.map(BasicCrop::new, BasicCrop::getBasicProperties);
    public static final RecipeSerializer<BasicCrop> SERIALIZER = DataHelper.recipeSerializer(CODEC, STREAM);

    private final Properties properties;

    /**
     * Creates the default soil ingredient. The item lookup must be provided by the current registry context, as tag
     * holder sets are recreated when data is reloaded.
     *
     * @param items The item lookup to resolve the tag from.
     * @return An ingredient for the default dirt soil tag.
     */
    public static Ingredient dirt(HolderGetter<Item> items) {
        return Ingredient.of(items.getOrThrow(DIRT_TAG));
    }

    public BasicCrop(Properties properties) {
        this.properties = properties;
    }

    public Properties getBasicProperties() {
        return this.properties;
    }

    @Override
    public boolean matches(@NotNull BotanyPotContext input, @NotNull Level level) {
        if (input instanceof BlockEntityContext context && this.properties.potPredicate.isPresent() && !this.properties.potPredicate.get().matches(context.blockInWorld())) {
            return false;
        }
        return this.properties.input.test(input.getSeedItem());
    }

    @Override
    public boolean couldMatch(ItemStack candidate, BotanyPotContext context, Level level) {
        return this.properties.input.test(candidate);
    }

    @Override
    public void onHarvest(BotanyPotContext context, Level level, Consumer<ItemStack> drops) {
        for (ItemDropProvider provider : this.properties.drops) {
            provider.apply(context, level, drops);
        }
        if (level instanceof ServerLevel serverLevel) {
            this.properties.functionId.ifPresent(context::runFunction);
        }
    }

    @Override
    public List<Display> getDisplayState(BotanyPotContext context, Level level) {
        return this.properties.display;
    }

    @Override
    public int getRequiredGrowthTicks(BotanyPotContext context, Level level) {
        return this.properties.growTime;
    }

    @Override
    public boolean isGrowthSustained(BotanyPotContext context, Level level) {
        return this.properties.soil.test(context.getSoilItem());
    }

    @Override
    public float getBaseYield(BotanyPotContext context, Level level) {
        return this.properties.baseYield;
    }

    @Override
    public float getYieldScale(BotanyPotContext context, Level level) {
        return this.properties.yieldScale;
    }

    @Override
    public boolean canBeCached() {
        return true;
    }

    @Override
    public boolean isCacheKey(ItemStack stack) {
        return properties.input.test(stack);
    }

    @NotNull
    @Override
    public RecipeSerializer<? extends Recipe<BotanyPotContext>> getSerializer() {
        return SERIALIZER;
    }

    @Override
    public void hoverTooltip(ItemStack stack, BotanyPotContext context, Level level, Consumer<Component> tooltipLines) {
        if (stack == context.getItem(BotanyPotBlockEntity.SEED_SLOT)) {
            if (this.isGrowthSustained(context, level)) {
                tooltipLines.accept(Component.translatable("tooltip.botanypots.growth_time", StringUtil.formatTickDuration(context.getRequiredGrowthTicks(), level.tickRateManager().tickrate())).withStyle(ChatFormatting.GRAY));
            }
            final float effectiveYield = Helpers.getTotalYield(context, level, this, context.getSoil());
            if (effectiveYield != 1f) {
                final float yieldScale = this.getYieldScale(context, level);
                tooltipLines.accept(Component.translatable("tooltip.botanypots.yield.total", Helpers.chanceToInt(effectiveYield)).withStyle(ChatFormatting.GRAY));
                final float baseYield = this.getBaseYield(context, level);
                if (effectiveYield != baseYield) {
                    tooltipLines.accept(Helpers.indent(Component.translatable("tooltip.botanypots.yield.source.base", Helpers.chanceToInt(this.getBaseYield(context, level))).withStyle(ChatFormatting.DARK_GRAY)));
                    final float soilYield = context.getSoil() != null ? context.getSoil().getYieldModifier(context, level) : 0f;
                    if (soilYield != 0f) {
                        tooltipLines.accept(Helpers.indent(Helpers.withScale(Component.translatable("tooltip.botanypots.yield.source.soil", Helpers.chanceToInt(soilYield)), yieldScale).withStyle(ChatFormatting.DARK_GRAY)));
                    }
                    if (context instanceof BlockEntityContext beContext && beContext.pot().getBlockState().getBlock() instanceof BotanyPotBlock potBlock) {
                        float potYield = potBlock.getYieldModifier(context, level, this, context.getSoil());
                        if (potYield != 0f) {
                            tooltipLines.accept(Helpers.indent(Helpers.withScale(Component.translatable("tooltip.botanypots.yield.source.pot", Helpers.chanceToInt(potYield)), yieldScale).withStyle(ChatFormatting.DARK_GRAY)));
                        }
                    }
                    float toolYield = (float) Helpers.getAttributeValue(Helpers.YIELD_MOD_ATTRIBUTE.get(), context.getHarvestItem(), 0f);
                    if (toolYield != 0f) {
                        tooltipLines.accept(Helpers.indent(Helpers.withScale(Component.translatable("tooltip.botanypots.yield.source.tool", Helpers.chanceToInt(toolYield)), yieldScale).withStyle(ChatFormatting.DARK_GRAY)));
                    }
                }
            }
            if (!this.properties.soil.test(context.getItem(BotanyPotBlockEntity.SOIL_SLOT))) {
                tooltipLines.accept(Component.translatable("tooltip.botanypots.wrong_soil", context.getSoilItem().getHoverName()).withStyle(ChatFormatting.RED));
            }
            if (context instanceof BlockEntityContext beContext && this.properties.potPredicate.isPresent() && !this.properties.potPredicate.get().matches(beContext.blockInWorld())) {
                tooltipLines.accept(Component.translatable("tooltip.botanypots.wrong_pot", beContext.pot().getBlockState().getBlock().getName()).withStyle(ChatFormatting.RED));
            }
        }
        else {
            tooltipLines.accept(Component.translatable("tooltip.botanypots.growth_time", StringUtil.formatTickDuration(this.properties.growTime, level.tickRateManager().tickrate())).withStyle(ChatFormatting.GRAY));
            final float dropChance = this.getBaseYield(context, level);
            if (dropChance != 1f) {
                tooltipLines.accept(Component.translatable("tooltip.botanypots.yield.total", Helpers.chanceToInt(dropChance)).withStyle(ChatFormatting.GRAY));
            }
            final float dropScale = this.getYieldScale(context, level);
            if (dropScale != 1f) {
                tooltipLines.accept(Component.translatable("tooltip.botanypots.yield.scale", Helpers.chanceToInt(dropScale)).withStyle(ChatFormatting.GRAY));
            }
        }
    }

    public boolean isValidSoil(ItemStack stack) {
        return this.properties.soil.test(stack);
    }

    public record Properties(Ingredient input, Ingredient soil, int growTime, List<Display> display, int lightLevel, List<ItemDropProvider> drops, Optional<Identifier> functionId, Optional<BlockPredicate> potPredicate, float baseYield, float yieldScale) {
        public static final MapCodec<Properties> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Ingredient.CODEC.fieldOf("input").forGetter(Properties::input),
                Ingredient.CODEC.optionalFieldOf("soil").forGetter(p -> Optional.of(p.soil())),
                Codec.intRange(1, Integer.MAX_VALUE).optionalFieldOf("grow_time", 1200).forGetter(Properties::growTime),
                DisplayType.LIST_CODEC.fieldOf("display").forGetter(Properties::display),
                Codec.intRange(0, 15).optionalFieldOf("light_level", 0).forGetter(Properties::lightLevel),
                MapCodecs.flexibleList(ItemDropProviderType.DROP_PROVIDER_CODEC).optionalFieldOf("drops", List.of()).forGetter(Properties::drops),
                Identifier.CODEC.optionalFieldOf("function").forGetter(Properties::functionId),
                BlockPredicate.CODEC.optionalFieldOf("pot_predicate").forGetter(Properties::potPredicate),
                Codec.floatRange(0f, Float.MAX_VALUE).optionalFieldOf("yield", 1f).forGetter(Properties::baseYield),
                Codec.floatRange(0f, Float.MAX_VALUE).optionalFieldOf("yield_scale", 1f).forGetter(Properties::yieldScale),
                RegistryOps.retrieveGetter(Registries.ITEM)
        ).apply(instance, (input, soil, growTime, display, lightLevel, drops, functionId, potPredicate, baseYield, yieldScale, items) -> new Properties(input, soil.orElseGet(() -> dirt(items)), growTime, display, lightLevel, drops, functionId, potPredicate, baseYield, yieldScale)));

        public static final StreamCodec<RegistryFriendlyByteBuf, Properties> STREAM = new StreamCodec<>() {
            @NotNull
            @Override
            public Properties decode(@NotNull RegistryFriendlyByteBuf buf) {
                final Ingredient input = Helpers.INGREDIENT_NON_EMPTY.decode(buf);
                final Ingredient soil = Helpers.INGREDIENT_NON_EMPTY.decode(buf);
                final int growTime = ByteBufCodecs.INT.decode(buf);
                final List<Display> display = buf.readList(DisplayType.DISPLAY_STATE_STREAM);
                final int light = ByteBufCodecs.INT.decode(buf);
                final Optional<Identifier> functionId = buf.readOptional(Identifier.STREAM_CODEC);

                final int dropSize = buf.readInt();
                final List<ItemDropProvider> drops = new LinkedList<>();
                for (int i = 0; i < dropSize; i++) {
                    drops.add(ItemDropProviderType.DROP_PROVIDER_STREAM.decode(buf));
                }
                final Optional<BlockPredicate> potPredicate = Helpers.OPTIONAL_BLOCK_PREDICATE.decode(buf);
                final float baseYield = buf.readFloat();
                final float yieldModifier = buf.readFloat();
                return new Properties(input, soil, growTime, display, light, drops, functionId, potPredicate, baseYield, yieldModifier);
            }

            @Override
            public void encode(@NotNull RegistryFriendlyByteBuf buf, @NotNull Properties properties) {
                Helpers.INGREDIENT_NON_EMPTY.encode(buf, properties.input);
                Helpers.INGREDIENT_NON_EMPTY.encode(buf, properties.soil);
                ByteBufCodecs.INT.encode(buf, properties.growTime);
                buf.writeCollection(properties.display, DisplayType.DISPLAY_STATE_STREAM);
                ByteBufCodecs.INT.encode(buf, properties.lightLevel);
                buf.writeOptional(properties.functionId, Identifier.STREAM_CODEC);
                buf.writeInt(properties.drops.size());
                for (ItemDropProvider provider : properties.drops) {
                    ItemDropProviderType.DROP_PROVIDER_STREAM.encode(buf, provider);
                }
                Helpers.OPTIONAL_BLOCK_PREDICATE.encode(buf, properties.potPredicate);
                buf.writeFloat(properties.baseYield);
                buf.writeFloat(properties.yieldScale);
            }
        };
    }
}