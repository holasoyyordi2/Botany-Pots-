# BotanyTrees 26.3 (port no oficial + español) – contenido fuente

Mod original: Darkhax, licencia LGPL v2.1 (license_botanytrees.txt).

Este mod no tiene código Java: solo datos. La carpeta BotanyTrees-26.3-es es exactamente el contenido del .jar:
- fabric.mod.json  (dependencias de 26.3, sin clases ni mixins)
- pack.mcmeta      (formato 121)
- data/botanytrees/recipe y loot_table (745 archivos JSON, + roble pálido)
- assets/botanytrees/lang (traducciones es_* para Mod Menu)

Para generar el .jar: comprime el CONTENIDO de la carpeta (no la carpeta) en un zip y renómbralo a .jar.
    cd BotanyTrees-26.3-es && zip -r ../botanytrees-fabric-26_3-26.3.0-es.jar .
